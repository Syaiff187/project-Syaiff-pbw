@extends('layoutt.main')

@section('content')
  <h1>About</h1>

  <h3>{{ $pembuat }}</h3>


@endsection