

<?php $__env->startSection('content'); ?>
  <div class="container mt-4">
    <h1 class="text-center mb-4">Kontak</h1>

    <div class="card shadow-lg p-4 mx-auto text-center" 
         style="max-width: 500px; border-radius: 15px; background-color: #F1F0E4;">
      
      <div class="mb-3">
        <i class="bi bi-envelope-fill" style="font-size: 3rem; color: #0d6efd;"></i>
      </div>
      
      <h3 class="mb-2"><?php echo e($gmail); ?></h3>
      <a href="mailto:<?php echo e($gmail); ?>" class="btn btn-primary">
        <i class="bi bi-send-fill"></i> Kirim Email
      </a>
    </div>
  </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layoutt.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TEKNOLOGI INFORMASI\projectPBW\resources\views/kontak.blade.php ENDPATH**/ ?>