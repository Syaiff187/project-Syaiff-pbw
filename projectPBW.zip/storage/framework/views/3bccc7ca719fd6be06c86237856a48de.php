

<?php $__env->startSection('content'); ?>
<h1>Edit Data Mahasiswa</h1>
<div class="card">
    <div class="card-body">
<form action="/editdata/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="name" class="form-label">Nama</label>
    <input type="text" name="name" id="nama" value="<?php echo e($data['name']); ?>" placeholder="Nama Lengkap" class="form-control" >
  <div class="mb-3">
    <label for="nim" class="form-label">Nomor Induk Mahasiswa</label>
    <input type="number" name="nim" id="nim" value="<?php echo e($data['nim']); ?>" class="form-control" >
  </div>
  <div class="mb-3">
    <label for="prodi" class="form-label">Program Studi</label>
    <input type="text" name="prodi" id="prodi" value="<?php echo e($data['prodi']); ?>" class="form-control" >
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" id="email" value="<?php echo e($data['email']); ?>" class="form-control" >
  </div>
  <div class="mb-3">
    <label for="nohp" class="form-label">Nomor Handphone</label>
    <input type="number" name="nohp" id="nohp" value="<?php echo e($data['nohp']); ?>" class="form-control" >
  </div>
  <button type="submit" class="btn btn-primary">Edit Data</button>
</form>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutt.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TEKNOLOGI INFORMASI\projectPBW\resources\views/edit.blade.php ENDPATH**/ ?>