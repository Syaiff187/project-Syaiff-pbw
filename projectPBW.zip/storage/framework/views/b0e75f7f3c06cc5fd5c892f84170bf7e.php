

<?php $__env->startSection('content'); ?>
<h1 class="text-center">Data Mahasiswa</h1>
    <div class="row mt-4"> 
      <a href="/tambahmahasiswa">
        <button type="button" class="btn btn-success mb-2">Tambah Data +</button>
</a>
<br>
<?php if($message = Session::get('success')): ?>
<div class="alert alert-success" role="alert">
   <?php echo e($message); ?>

</div>
<?php endif; ?>
        <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">NIM</th>
      <th scope="col">Prodi</th>
      <th scope="col">Email</th>
      <th scope="col">No.Hp</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $i=1 ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo $i ?></th>
      <td><?php echo e($mahasiswa["name"]); ?></td>
      <td><?php echo e($mahasiswa["nim"]); ?></td>
      <td><?php echo e($mahasiswa["prodi"]); ?></td>
      <td><?php echo e($mahasiswa["email"]); ?></td>
      <td><?php echo e($mahasiswa["nohp"]); ?></td>
      <td>


      <a href="/tampildata/<?php echo e($mahasiswa->id); ?>" class="btn btn-primary">Edit</a>
      <a href="/deletedata/<?php echo e($mahasiswa->id); ?>" class="btn btn-danger"
      onclick="return confirm('yakin hapus?')" >Delete</a>
      
</td>
<?php $i++ ?>
    </tr>
    <tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layoutt.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TEKNOLOGI INFORMASI\projectPBW\resources\views/mahasiswa.blade.php ENDPATH**/ ?>